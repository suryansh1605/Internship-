from django.shortcuts import render
import pickle
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, classification_report

# Create your views here.
def home(request):
    return render(request, 'index.html')

def getPredictions(Age,Duration,Frequency,Location,Character,Intensity,Nausea,Vomit,Phonophobia,Photophobia,Visual,Sensory,Dysphasia,Dysarthria,Vertigo,Tinnitus,Hypoacusis,Diplopia,Defect,Ataxia,Conscience,Paresthesia,DPF):
    data = pd.read_csv('C:\\Users\\lenovo\\Desktop\\Suryansh_ML\\models\\data.csv')
    import sklearn
    from sklearn.preprocessing import LabelEncoder
    le = LabelEncoder()
    data['Type_n'] = le.fit_transform(data['Type'])
    import sklearn
    X=data.drop(['Type','Type_n'],axis=1)
    y=data['Type_n']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Standardize the features (important for KNN)
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)

    # Create a KNN classifier
    k = 8  # You can choose the value of k based on your requirement
    knn_classifier = KNeighborsClassifier(n_neighbors=k)

    # Train the classifier
    knn_classifier.fit(X_train, y_train)

    # Make predictions on the test set
    y_pred = knn_classifier.predict(X_test)

    # Evaluate the model
    accuracy = accuracy_score(y_test, y_pred)
    classification_report_str = classification_report(y_test, y_pred)

    # Print the results
    # print(f'Accuracy: {accuracy:.2f}')
    # print('Classification Report:\n', classification_report_str)
    prediction = knn_classifier.predict([
        [Age,Duration,Frequency,Location,Character,Intensity,Nausea,Vomit,Phonophobia,Photophobia,Visual,Sensory,Dysphasia,Dysarthria,Vertigo,Tinnitus,Hypoacusis,Diplopia,Defect,Ataxia,Conscience,Paresthesia,DPF]])

    if prediction == 0:
        return 'no'
    elif prediction == 1:
        return 'yes'
    elif prediction==5:
        return 'y'
    elif prediction==2:
        return 'n'
    elif prediction==6:
        return 'u'
    elif prediction==3:
        return 'r'
    elif prediction==4:
        return 's'
    else:
        return 'error'


def result(request):
    Age = int(request.GET['Age'])
    Duration = int(request.GET['Duration'])
    Frequency = int(request.GET['Frequency'])
    Location = int(request.GET['Location'])
    Character = int(request.GET['Character'])
    Intensity = int(request.GET['Intensity'])
    Nausea = int(request.GET['Nausea'])
    Vomit = int(request.GET['Vomit'])
    Phonophobia = int(request.GET['Phonophobia'])
    Photophobia = int(request.GET['Photophobia'])
    Visual = int(request.GET['Visual'])
    Sensory = int(request.GET['Sensory'])
    Dysphasia = int(request.GET['Dysphasia'])
    Dysarthria = int(request.GET['Dysarthria'])
    Vertigo = int(request.GET['Vertigo'])
    Tinnitus = int(request.GET['Tinnitus'])
    Hypoacusis = int(request.GET['Hypoacusis'])
    Diplopia = int(request.GET['Diplopia'])
    Defect = int(request.GET['Defect'])
    Ataxia = int(request.GET['Ataxia'])
    Conscience = int(request.GET['Conscience'])
    Paresthesia = int(request.GET['Paresthesia'])
    DPF = int(request.GET['DPF'])



    result = getPredictions(Age,Duration,Frequency,Location,Character,Intensity,Nausea,Vomit,Phonophobia,Photophobia,Visual,Sensory,Dysphasia,Dysarthria,Vertigo,Tinnitus,Hypoacusis,Diplopia,Defect,Ataxia,Conscience,Paresthesia,DPF)
    return render(request, 'result.html', {'result': result})